"""Briques de description des formulaires de la page web : champs, tableaux éditables, groupes.

Chaque champ est un dict JSON que docs/js/machine.js sait dessiner. Aucune logique de calcul ici.
"""


def nb(ident, libelle, unite="", mini=None, maxi=None, aide="", entier=False, exclu=False):
    """Champ numérique (virgule ou point acceptés), borné si mini ou maxi ; `exclu` : la borne mini elle-même est refusée (> mini)."""
    securite = ident == "s" and libelle.startswith("Coefficient de sécurité")
    exclu = bool(exclu and mini is not None) or (securite and (mini is None or mini <= 0))  # s = 0 n'a pas de sens : strictement positif
    return {"id": ident, "type": "nombre", "libelle": libelle, "unite": unite, "min": 0.0 if exclu else mini, "max": maxi, "aide": aide,
            "entier": entier, "minExclu": exclu,
            # coefficient de sécurité s : la page propose aussi la marge en % (marge = s − 1), le calcul garde s
            "securite": securite}  # fmt: skip


def liste(ident, libelle, options, aide="", etiquettes=None):
    """Liste déroulante ; `etiquettes` : textes affichés à la place des valeurs (même ordre)."""
    return {"id": ident, "type": "liste", "libelle": libelle, "options": list(options), "aide": aide,
            "etiquettes": list(etiquettes) if etiquettes else None}  # fmt: skip


def case(ident, libelle, aide=""):
    return {"id": ident, "type": "case", "libelle": libelle, "aide": aide}


def texte(ident, libelle, aide=""):
    return {"id": ident, "type": "texte", "libelle": libelle, "aide": aide}


def col(ident, libelle, genre="nombre", options=None, defaut=0.0, entier=False):
    """Colonne d'un tableau éditable : genre nombre, texte, liste ou case."""
    return {"id": ident, "libelle": libelle, "genre": genre, "options": list(options) if options else None,
            "defaut": defaut, "entier": entier}  # fmt: skip


def tableau(ident, libelle, colonnes, aide="", mini=0, polaire=None):
    """Tableau éditable : une ligne par élément (appui, charge, nœud…), lignes ajoutées ou retirées, collage Excel.

    `polaire` : {"norme", "angle", "plan" (ids de colonnes), "plans" : liste} : la page remplit les composantes Fx, Fy, Fz
    de la force inclinée (règle de services/forces.py, reprise par `majPolaire` de docs/js/machine.js)."""
    return {"id": ident, "type": "tableau", "libelle": libelle, "colonnes": colonnes, "aide": aide, "min": mini, "polaire": polaire}


def groupe(titre, *champs, ouvert=True, ligne=False, note=""):
    return {"titre": titre, "champs": list(champs), "ouvert": ouvert, "ligne": ligne, "note": note}
